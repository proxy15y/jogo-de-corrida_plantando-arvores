function setup() {
  createCanvas(400, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;

function draw() {
  if(focused == true){
    
     background('rgb(178,248,198)');
    
  }else{
     background('rgb(252,125,130)')
  }
  
  
  textSize(40);
  text("🌳", xJogador1, 100);
  text("🌲", xJogador2, 300);
  rect(350, 0, 10, 400);
  
  
  if (xJogador1 > 350) {
    text("Jogador 1 vence >:D", 10, 200);
    noLoop();
  }
  if (xJogador2 > 350) {
    text("Jogador 2 venceu >:D", 10, 200);
    noLoop();
  }
}

function keyReleased() {
  if (key === '6') {
     xJogador1 += random(15);
  }
   if(key == 's'){
     xJogador2 += random(15);
   }
}
  